﻿using System.ComponentModel.DataAnnotations;

namespace TicketStationMVC.ViewModels.Category
{
    public class CategoryVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
